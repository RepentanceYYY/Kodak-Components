﻿
namespace ArchivesManage
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Scan_MyScan = new AxScanLibCtl.AxImgScan();
            this.btnOpenScan = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Scan_MyScan)).BeginInit();
            this.SuspendLayout();
            // 
            // Scan_MyScan
            // 
            this.Scan_MyScan.Enabled = true;
            this.Scan_MyScan.Location = new System.Drawing.Point(621, 88);
            this.Scan_MyScan.Name = "Scan_MyScan";
            this.Scan_MyScan.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Scan_MyScan.OcxState")));
            this.Scan_MyScan.Size = new System.Drawing.Size(32, 32);
            this.Scan_MyScan.TabIndex = 0;
            // 
            // btnOpenScan
            // 
            this.btnOpenScan.Location = new System.Drawing.Point(138, 69);
            this.btnOpenScan.Name = "btnOpenScan";
            this.btnOpenScan.Size = new System.Drawing.Size(75, 23);
            this.btnOpenScan.TabIndex = 3;
            this.btnOpenScan.Text = "button1";
            this.btnOpenScan.UseVisualStyleBackColor = true;
            this.btnOpenScan.Click += new System.EventHandler(this.btnOpenScan_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnOpenScan);
            this.Controls.Add(this.Scan_MyScan);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Scan_MyScan)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AxScanLibCtl.AxImgScan Scan_MyScan;
        private System.Windows.Forms.Button btnOpenScan;
    }
}

