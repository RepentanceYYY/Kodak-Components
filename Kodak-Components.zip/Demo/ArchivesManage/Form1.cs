﻿using ScanLibCtl;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArchivesManage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOpenScan_Click(object sender, EventArgs e)
        {
            try
            {
                //Scan_MyScan.ShowScanNew(true);
                int iScanFlag = Scan_MyScan.ShowSelectScanner();//选择扫描仪 9233
                if (iScanFlag != 0)
                {
                    return;
                }
                int iOpen = Scan_MyScan.OpenScanner(); //打开扫描仪 
                ScanConfig(Scan_MyScan, iOpen);//扫描仪配置
            }
            catch (Exception)
            {

                Scan_MyScan.CloseScanner();
            }
        }
        #region  配置扫描仪
        public void ScanConfig(AxScanLibCtl.AxImgScan mysCan, int iOpen)//配置扫描仪
        {
            if (iOpen == 0)
            {
                if (mysCan.ScannerAvailable() == true)//判断扫描仪是否可用 
                {
                    string pathGen = @"C:\Users\爱丽丝梦游仙境XHRO-g\Desktop\img";//扫描仪的图片缓存路径
                    //判断缓存路径是否存在，如果不存在的话就根据路径创建文件夹
                    if (!System.IO.Directory.Exists(pathGen))
                    {
                        System.IO.Directory.CreateDirectory(pathGen);//不存在就创建目录 
                    }
                    mysCan.MultiPage = true;//是否多页 
                    mysCan.PageCount += 1;

                    //string paths = pathGen + "//app.path" + "UN";
                    mysCan.Image = pathGen + "\\Img";
                    mysCan.FileType = FileTypeConstants.JPG_File;//FileTypeConstants.BMP_Bitmap;//设置文件类型 
                    mysCan.CompressionType = CompressionTypeConstants.JPEG;
                    mysCan.ScanTo = ScanToConstants.DisplayAndUseFileTemplate;
                    mysCan.SetPageTypeCompressionOpts(CompPreferenceConstants.GoodDisplay, ImageTypeConstants.BlackAndWhite1Bit, CompTypeConstants.JPEGCompression, CompInfoConstants.G31DFaxRBO);
                    mysCan.StopScanBox = false;
                    mysCan.ShowSetupBeforeScan = true;//是否在扫描前显示设置界面 
                    mysCan.Show();
                    iOpen = mysCan.StartScan();//开始扫描 如果扫描仪是关闭的，该方法将打开扫描仪并在扫描完毕后重新关闭。 
                    if (iOpen == 0)//如果扫描仪开启开执行这里
                    {
                        try//将刚扫描出来的图片转换为JPG格式，再展示在图片控件上面
                        {

                        }
                        catch
                        {
                            mysCan.CloseScanner(); //关闭扫描仪
                        }
                        //Byte[] filebyte = GetScanFileByte(mysCan.Image);
                    }
                    else//扫描仪未开启成功执行这里
                    {
                        //MessageBox.Show("扫描仪没有正确连接或扫描控件已破坏,请检查!", "系统提示");//控件自带弹框提示，所以注释掉

                    }

                    mysCan.CloseScanner(); //关闭扫描仪
                    var filePath =  GetLatestFileInFolder(pathGen);
                    var newFilePath = @"C:\Users\爱丽丝梦游仙境XHRO-g\Desktop\img\新建文本文档.png";
                    ConvertBmpToPngAndDelete(filePath, newFilePath);
                    File.Delete(filePath);

                }
                else//如果扫描仪没连接走这里
                {
                    MessageBox.Show("扫描仪没有正确连接,请重新设置!");
                }

            }
            else if (iOpen == 9219)// 如果扫描仪没连接走这里
            {
                MessageBox.Show("系统没有安装扫描仪或扫描仪没有正确连接！", "系统提示");
            }
        }
        #endregion
        /// <summary>
        /// 获取文件夹中最新添加的文件
        /// </summary>
        /// <param name="folderPath"></param>
        /// <returns></returns>
        public static string GetLatestFileInFolder(string folderPath)
        {
            try
            {
                // 检查文件夹是否存在
                if (!Directory.Exists(folderPath))
                {
                    throw new DirectoryNotFoundException("文件夹不存在");
                }

                // 获取文件夹中的所有文件
                string[] files = Directory.GetFiles(folderPath);

                // 如果没有文件，则返回空字符串
                if (files.Length == 0)
                {
                    return string.Empty;
                }

                // 使用LINQ查询获取最新的文件
                var latestFile = files
                    .Select(filePath => new FileInfo(filePath))
                    .OrderByDescending(fileInfo => fileInfo.LastWriteTime)
                    .First();

                // 返回最新文件的完整路径
                return latestFile.FullName;
            }
            catch (Exception ex)
            {
                // 处理任何可能的异常
                Console.WriteLine($"获取最新文件时发生异常：{ex.Message}");
                return string.Empty;
            }
        }
        /// <summary>
        /// 将图片转成png类型
        /// </summary>
        /// <param name="inputBmpPath"></param>
        /// <param name="outputPngPath"></param>
        public static void ConvertBmpToPngAndDelete(string inputBmpPath, string outputPngPath)
        {
            try
            {
                // 打开BMP图像文件
                using (Bitmap bmp = new Bitmap(inputBmpPath))
                {
                    // 将BMP图像保存为PNG图像
                    bmp.Save(outputPngPath, ImageFormat.Png);
                }

                // 删除原始BMP文件
                File.Delete(inputBmpPath);
                Console.WriteLine($"原始BMP图像已成功删除");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
